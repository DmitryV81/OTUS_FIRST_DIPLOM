-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `cond_instances`
--

DROP TABLE IF EXISTS `cond_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cond_instances` (
  `NAME` varchar(128) NOT NULL,
  `OBJECT_INSTANCE_BEGIN` bigint unsigned NOT NULL,
  PRIMARY KEY (`OBJECT_INSTANCE_BEGIN`),
  KEY `NAME` (`NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cond_instances`
--

LOCK TABLES `cond_instances` WRITE;
/*!40000 ALTER TABLE `cond_instances` DISABLE KEYS */;
INSERT INTO `cond_instances` VALUES ('wait/synch/cond/sql/COND_manager',64570272),('wait/synch/cond/sql/COND_server_started',64532960),('wait/synch/cond/sql/COND_compress_gtid_table',64532768),('wait/synch/cond/sql/COND_socket_listener_active',64532576),('wait/synch/cond/sql/COND_start_signal_handler',64532448),('wait/synch/cond/sql/MYSQL_BIN_LOG::update_cond',65188208),('wait/synch/cond/sql/MYSQL_BIN_LOG::prep_xids_cond',65190760),('wait/synch/cond/sql/MYSQL_BIN_LOG::COND_done',65191296),('wait/synch/cond/sql/MYSQL_BIN_LOG::COND_done',65191352),('wait/synch/cond/sql/MYSQL_BIN_LOG::COND_flush_queue',65191240),('wait/synch/cond/sql/COND_thread_cache',65094784),('wait/synch/cond/sql/COND_flush_thread_cache',65094720),('wait/synch/cond/sql/COND_connection_count',65171456),('wait/synch/cond/sql/COND_thd_list',109087480),('wait/synch/cond/sql/COND_thd_list',109087536),('wait/synch/cond/sql/COND_thd_list',109087592),('wait/synch/cond/sql/COND_thd_list',109087648),('wait/synch/cond/sql/COND_thd_list',109087704),('wait/synch/cond/sql/COND_thd_list',109087760),('wait/synch/cond/sql/COND_thd_list',109087816),('wait/synch/cond/sql/COND_thd_list',109087872),('wait/synch/cond/sql/COND_open',64556192),('wait/synch/cond/myisam/keycache_thread_var::suspend',65376672),('wait/synch/cond/sql/Source_info::data_cond',112498864),('wait/synch/cond/sql/Source_info::start_cond',112498920),('wait/synch/cond/sql/Source_info::stop_cond',112498976),('wait/synch/cond/sql/MDL_context::COND_wait_status',140559384983136),('wait/synch/cond/sql/COND_thr_lock',140559384988536),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140559384994920),('wait/synch/cond/innodb/commit_cond',65246080),('wait/synch/cond/innodb/resume_encryption_cond',65245952),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558911671424),('wait/synch/cond/sql/COND_thr_lock',140558911676824),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558911683208),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558844562560),('wait/synch/cond/sql/COND_thr_lock',140558844567960),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558844574344),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558710344832),('wait/synch/cond/sql/COND_thr_lock',140558710350232),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558710356616),('wait/synch/cond/sql/Source_info::sleep_cond',112499032),('wait/synch/cond/sql/Source_info::rotate_cond',112501000),('wait/synch/cond/sql/Relay_log_info::data_cond',114052720),('wait/synch/cond/sql/Relay_log_info::start_cond',114052776),('wait/synch/cond/sql/Relay_log_info::stop_cond',114052832),('wait/synch/cond/sql/Relay_log_info::sleep_cond',114052888),('wait/synch/cond/sql/Relay_log_info::log_space_cond',114059120),('wait/synch/cond/sql/Relay_log_info::pending_jobs_cond',114060776),('wait/synch/cond/sql/Relay_log_info::mta_gaq_cond',114053376),('wait/synch/cond/sql/MYSQL_RELAY_LOG::update_cond',114054544),('wait/synch/cond/sql/COND_queue_state',113903648),('wait/synch/cond/sql/Event_scheduler::COND_state',113903872),('wait/synch/cond/sql/MDL_context::COND_wait_status',114435664),('wait/synch/cond/sql/COND_thr_lock',114441064),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',114447448),('wait/synch/cond/mysqlx/scheduler_dynamic_worker_pending',110734656),('wait/synch/cond/mysqlx/scheduler_dynamic_thread_exit',110734760),('wait/synch/cond/mysqlx/socket_acceptors_sync',110714392),('wait/synch/cond/mysqlx/broker_context_sync',110580040),('wait/synch/cond/mysqlx/scheduler_dynamic_worker_pending',110651104),('wait/synch/cond/mysqlx/scheduler_dynamic_thread_exit',110651208),('wait/synch/cond/mysqlx/server_state_sync',110651744),('wait/synch/cond/mysqlx/listener_tcp_sync',110656224),('wait/synch/cond/mysqlx/listener_unix_socket_sync',110656456),('wait/synch/cond/sql/MDL_context::COND_wait_status',114161712),('wait/synch/cond/sql/COND_thr_lock',114167112),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',114173496),('wait/synch/cond/sql/MDL_context::COND_wait_status',110582176),('wait/synch/cond/sql/COND_thr_lock',110587576),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',110593960),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558576135568),('wait/synch/cond/sql/COND_thr_lock',140558576140968),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558576147352),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558777453760),('wait/synch/cond/sql/COND_thr_lock',140558777459160),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558777465544),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558710366112),('wait/synch/cond/sql/COND_thr_lock',140558710371512),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558710377896),('wait/synch/cond/sql/MDL_context::COND_wait_status',140558844583184),('wait/synch/cond/sql/COND_thr_lock',140558844588584),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140558844594968),('wait/synch/cond/sql/Source_IO_monitor::run_cond',110243800),('wait/synch/cond/sql/MDL_context::COND_wait_status',140559065022976),('wait/synch/cond/sql/COND_thr_lock',140559065028376),('wait/synch/cond/sql/THD::COND_group_replication_connection_cond_var',140559065034760),('wait/synch/cond/sql/Gtid_state',110043152),('wait/synch/cond/sql/Gtid_state',110654288);
/*!40000 ALTER TABLE `cond_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:05
