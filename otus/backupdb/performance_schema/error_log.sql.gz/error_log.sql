-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `error_log`
--

DROP TABLE IF EXISTS `error_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `error_log` (
  `LOGGED` timestamp(6) NOT NULL,
  `THREAD_ID` bigint unsigned DEFAULT NULL,
  `PRIO` enum('System','Error','Warning','Note') NOT NULL,
  `ERROR_CODE` varchar(10) DEFAULT NULL,
  `SUBSYSTEM` varchar(7) DEFAULT NULL,
  `DATA` text NOT NULL,
  PRIMARY KEY (`LOGGED`),
  KEY `THREAD_ID` (`THREAD_ID`),
  KEY `PRIO` (`PRIO`),
  KEY `ERROR_CODE` (`ERROR_CODE`),
  KEY `SUBSYSTEM` (`SUBSYSTEM`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_log`
--

LOCK TABLES `error_log` WRITE;
/*!40000 ALTER TABLE `error_log` DISABLE KEYS */;
INSERT INTO `error_log` VALUES ('2022-08-17 05:33:05.424229',0,'System','MY-013169','Server','/usr/sbin/mysqld (mysqld 8.0.30) initializing of server in progress as process 1867'),('2022-08-17 05:33:05.448709',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 05:33:08.238804',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 05:33:11.413450',6,'Note','MY-010454','Server','A temporary password is generated for root@localhost: ct&i=qZ%m1LZ'),('2022-08-17 05:33:18.273198',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1913'),('2022-08-17 05:33:18.298721',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 05:33:19.184310',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 05:33:20.064291',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 05:33:20.064392',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 05:33:20.118814',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 05:33:20.118962',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 05:33:21.686879',0,'System','MY-013172','Server','Received SHUTDOWN from user <via user signal>. Shutting down mysqld (Version: 8.0.30).'),('2022-08-17 05:33:23.213547',0,'System','MY-010910','Server','/usr/sbin/mysqld: Shutdown complete (mysqld 8.0.30)  MySQL Community Server - GPL.'),('2022-08-17 05:33:23.711752',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 2073'),('2022-08-17 05:33:23.726124',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 05:33:24.547629',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 05:33:25.152927',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 05:33:25.153015',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 05:33:25.199971',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 05:33:25.200188',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 06:13:06.464329',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1041'),('2022-08-17 06:13:06.545301',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 06:13:08.000200',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 06:13:08.435887',0,'System','MY-010229','Server','Starting XA crash recovery...'),('2022-08-17 06:13:08.449346',0,'System','MY-010232','Server','XA crash recovery finished.'),('2022-08-17 06:13:08.703455',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 06:13:08.703540',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 06:13:08.745571',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 06:13:08.746027',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 09:34:54.181533',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1038'),('2022-08-17 09:34:54.277206',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 09:34:55.832484',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 09:34:56.333168',0,'System','MY-010229','Server','Starting XA crash recovery...'),('2022-08-17 09:34:56.350453',0,'System','MY-010232','Server','XA crash recovery finished.'),('2022-08-17 09:34:56.615283',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 09:34:56.615370',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 09:34:56.660893',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 09:34:56.661439',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 10:53:40.381828',436,'Warning','MY-013712','Server','No suitable \'keyring_component_metadata_query\' service implementation found to fulfill the request.'),('2022-08-17 11:55:34.597749',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1039'),('2022-08-17 11:55:34.663644',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 11:55:36.290312',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 11:55:36.722018',0,'System','MY-010229','Server','Starting XA crash recovery...'),('2022-08-17 11:55:36.736415',0,'System','MY-010232','Server','XA crash recovery finished.'),('2022-08-17 11:55:37.017210',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 11:55:37.017295',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 11:55:37.060062',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 11:55:37.060590',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 13:34:37.132833',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1036'),('2022-08-17 13:34:37.231428',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 13:34:38.751133',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 13:34:39.243246',0,'System','MY-010229','Server','Starting XA crash recovery...'),('2022-08-17 13:34:39.259279',0,'System','MY-010232','Server','XA crash recovery finished.'),('2022-08-17 13:34:39.537134',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 13:34:39.537222',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 13:34:39.581808',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 13:34:39.582322',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 18:09:39.617041',0,'System','MY-010116','Server','/usr/sbin/mysqld (mysqld 8.0.30) starting as process 1040'),('2022-08-17 18:09:39.737507',1,'System','MY-013576','InnoDB','InnoDB initialization has started.'),('2022-08-17 18:09:41.235594',1,'System','MY-013577','InnoDB','InnoDB initialization has ended.'),('2022-08-17 18:09:41.727733',0,'System','MY-010229','Server','Starting XA crash recovery...'),('2022-08-17 18:09:41.746431',0,'System','MY-010232','Server','XA crash recovery finished.'),('2022-08-17 18:09:42.023596',0,'Warning','MY-010068','Server','CA certificate ca.pem is self signed.'),('2022-08-17 18:09:42.023685',0,'System','MY-013602','Server','Channel mysql_main configured to support TLS. Encrypted connections are now supported for this channel.'),('2022-08-17 18:09:42.096747',0,'System','MY-010931','Server','/usr/sbin/mysqld: ready for connections. Version: \'8.0.30\'  socket: \'/var/lib/mysql/mysql.sock\'  port: 3306  MySQL Community Server - GPL.'),('2022-08-17 18:09:42.097366',0,'System','MY-011323','Server','X Plugin ready for connections. Bind-address: \'::\' port: 33060, socket: /var/run/mysqld/mysqlx.sock'),('2022-08-17 18:16:48.602282',222,'Warning','MY-013712','Server','No suitable \'keyring_component_metadata_query\' service implementation found to fulfill the request.'),('2022-08-17 18:21:43.036994',608,'Warning','MY-013712','Server','No suitable \'keyring_component_metadata_query\' service implementation found to fulfill the request.'),('2022-08-17 18:23:26.651039',994,'Warning','MY-013712','Server','No suitable \'keyring_component_metadata_query\' service implementation found to fulfill the request.');
/*!40000 ALTER TABLE `error_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:05
