-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `events_statements_history`
--

DROP TABLE IF EXISTS `events_statements_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `events_statements_history` (
  `THREAD_ID` bigint unsigned NOT NULL,
  `EVENT_ID` bigint unsigned NOT NULL,
  `END_EVENT_ID` bigint unsigned DEFAULT NULL,
  `EVENT_NAME` varchar(128) NOT NULL,
  `SOURCE` varchar(64) DEFAULT NULL,
  `TIMER_START` bigint unsigned DEFAULT NULL,
  `TIMER_END` bigint unsigned DEFAULT NULL,
  `TIMER_WAIT` bigint unsigned DEFAULT NULL,
  `LOCK_TIME` bigint unsigned NOT NULL,
  `SQL_TEXT` longtext,
  `DIGEST` varchar(64) DEFAULT NULL,
  `DIGEST_TEXT` longtext,
  `CURRENT_SCHEMA` varchar(64) DEFAULT NULL,
  `OBJECT_TYPE` varchar(64) DEFAULT NULL,
  `OBJECT_SCHEMA` varchar(64) DEFAULT NULL,
  `OBJECT_NAME` varchar(64) DEFAULT NULL,
  `OBJECT_INSTANCE_BEGIN` bigint unsigned DEFAULT NULL,
  `MYSQL_ERRNO` int DEFAULT NULL,
  `RETURNED_SQLSTATE` varchar(5) DEFAULT NULL,
  `MESSAGE_TEXT` varchar(128) DEFAULT NULL,
  `ERRORS` bigint unsigned NOT NULL,
  `WARNINGS` bigint unsigned NOT NULL,
  `ROWS_AFFECTED` bigint unsigned NOT NULL,
  `ROWS_SENT` bigint unsigned NOT NULL,
  `ROWS_EXAMINED` bigint unsigned NOT NULL,
  `CREATED_TMP_DISK_TABLES` bigint unsigned NOT NULL,
  `CREATED_TMP_TABLES` bigint unsigned NOT NULL,
  `SELECT_FULL_JOIN` bigint unsigned NOT NULL,
  `SELECT_FULL_RANGE_JOIN` bigint unsigned NOT NULL,
  `SELECT_RANGE` bigint unsigned NOT NULL,
  `SELECT_RANGE_CHECK` bigint unsigned NOT NULL,
  `SELECT_SCAN` bigint unsigned NOT NULL,
  `SORT_MERGE_PASSES` bigint unsigned NOT NULL,
  `SORT_RANGE` bigint unsigned NOT NULL,
  `SORT_ROWS` bigint unsigned NOT NULL,
  `SORT_SCAN` bigint unsigned NOT NULL,
  `NO_INDEX_USED` bigint unsigned NOT NULL,
  `NO_GOOD_INDEX_USED` bigint unsigned NOT NULL,
  `NESTING_EVENT_ID` bigint unsigned DEFAULT NULL,
  `NESTING_EVENT_TYPE` enum('TRANSACTION','STATEMENT','STAGE','WAIT') DEFAULT NULL,
  `NESTING_EVENT_LEVEL` int DEFAULT NULL,
  `STATEMENT_ID` bigint unsigned DEFAULT NULL,
  `CPU_TIME` bigint unsigned NOT NULL,
  `EXECUTION_ENGINE` enum('PRIMARY','SECONDARY') DEFAULT NULL,
  PRIMARY KEY (`THREAD_ID`,`EVENT_ID`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events_statements_history`
--

LOCK TABLES `events_statements_history` WRITE;
/*!40000 ALTER TABLE `events_statements_history` DISABLE KEYS */;
INSERT INTO `events_statements_history` VALUES (1377,22,22,'statement/sql/show_create_table','init_net_server_extension.cc:95',990205093409000,990205299559000,206150000,0,'show create table `events_statements_history`','cb11a3b458a6d48a64cf2cefb22966d65a75ad82664a4c1e205ec4428772e1f5','SHOW CREATE TABLE `events_statements_history`','performance_schema',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28366,0,'PRIMARY'),(1377,23,23,'statement/sql/set_option','init_net_server_extension.cc:95',990205349187000,990205398306000,49119000,0,'SET SESSION character_set_results = \'utf8mb4\'','3e721af8c99794edb397e87d4f532280af6dcee72b6fe7602ea4bd53fd62c334','SET SESSION `character_set_results` = ?','performance_schema',NULL,NULL,NULL,NULL,0,'00000',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28367,0,'PRIMARY'),(1377,24,24,'statement/sql/show_fields','init_net_server_extension.cc:95',990205442443000,990207697942000,2255499000,4000000,'show fields from `events_statements_history`','2d8bcd9dd15a7e22eb18184e41736ec240e0e44b5144345d16a4ba0841a1b2b3','SHOW FIELDS FROM `events_statements_history`','performance_schema',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,0,44,179,0,1,0,0,0,0,1,0,0,44,1,0,0,9,'TRANSACTION',0,28368,0,'PRIMARY'),(1377,25,25,'statement/sql/show_fields','init_net_server_extension.cc:95',990207814952000,990209548609000,1733657000,2000000,'show fields from `events_statements_history`','2d8bcd9dd15a7e22eb18184e41736ec240e0e44b5144345d16a4ba0841a1b2b3','SHOW FIELDS FROM `events_statements_history`','performance_schema',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,0,44,179,0,1,0,0,0,0,1,0,0,44,1,0,0,9,'TRANSACTION',0,28369,0,'PRIMARY'),(1377,16,16,'statement/com/Init DB','init_net_server_extension.cc:95',990193794964000,990193879897000,84933000,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'00000',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28360,0,'PRIMARY'),(1377,17,17,'statement/sql/show_tables','init_net_server_extension.cc:95',990193987269000,990196215117000,2227848000,4000000,'SHOW TABLES LIKE \'events\\_statements\\_history\'','a72b965922848d2b5f697f9c499411910581b77921bbc4deaa2dc2e9473e937f','SHOW TABLES LIKE ?','performance_schema',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,0,1,115,0,0,0,0,0,0,1,0,0,1,1,0,0,9,'TRANSACTION',0,28361,0,'PRIMARY'),(1377,18,18,'statement/sql/savepoint','init_net_server_extension.cc:95',990196411877000,990196483252000,71375000,0,'SAVEPOINT sp','3347d96c3d340448bfc71f77e27c42e88551356e0b2549e05e7c28a07b710411','SAVEPOINT `sp`','performance_schema',NULL,NULL,NULL,NULL,0,'00000',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28362,0,'PRIMARY'),(1377,19,19,'statement/sql/show_table_status','init_net_server_extension.cc:95',990196533798000,990204697178000,8163380000,36000000,'show table status like \'events\\_statements\\_history\'','cb62f9bcae58a460fc985bfa6ed940c7d815b1a94c7fd7dd768819f9fd18a8fa','SHOW TABLE STATUS LIKE ?','performance_schema',NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,0,1,115,0,0,0,0,0,0,1,0,0,1,1,0,0,9,'TRANSACTION',0,28363,0,'PRIMARY'),(1377,20,20,'statement/sql/set_option','init_net_server_extension.cc:95',990204839401000,990204950819000,111418000,0,'SET SQL_QUOTE_SHOW_CREATE=1','c4b6889894c1d0b4b2f50105fa0e20d039abc513619b87ef888b1cf3af013fb6','SET `SQL_QUOTE_SHOW_CREATE` = ?','performance_schema',NULL,NULL,NULL,NULL,0,'00000',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28364,0,'PRIMARY'),(1377,21,21,'statement/sql/set_option','init_net_server_extension.cc:95',990204997448000,990205057325000,59877000,0,'SET SESSION character_set_results = \'binary\'','3e721af8c99794edb397e87d4f532280af6dcee72b6fe7602ea4bd53fd62c334','SET SESSION `character_set_results` = ?','performance_schema',NULL,NULL,NULL,NULL,0,'00000',NULL,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,'TRANSACTION',0,28365,0,'PRIMARY');
/*!40000 ALTER TABLE `events_statements_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:09
