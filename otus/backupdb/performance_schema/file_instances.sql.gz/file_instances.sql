-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `file_instances`
--

DROP TABLE IF EXISTS `file_instances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_instances` (
  `FILE_NAME` varchar(512) NOT NULL,
  `EVENT_NAME` varchar(128) NOT NULL,
  `OPEN_COUNT` int unsigned NOT NULL,
  PRIMARY KEY (`FILE_NAME`),
  KEY `EVENT_NAME` (`EVENT_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_instances`
--

LOCK TABLES `file_instances` WRITE;
/*!40000 ALTER TABLE `file_instances` DISABLE KEYS */;
INSERT INTO `file_instances` VALUES ('/usr/share/mysql-8.0/english/errmsg.sys','wait/io/file/sql/ERRMSG',0),('/usr/share/mysql-8.0/charsets/Index.xml','wait/io/file/mysys/charset',0),('/var/lib/mysql/auto.cnf','wait/io/file/mysys/cnf',0),('/var/lib/mysql/ibdata1','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#ib_16384_0.dblwr','wait/io/file/innodb/innodb_dblwr_file',2),('/var/lib/mysql/#ib_16384_1.dblwr','wait/io/file/innodb/innodb_dblwr_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo6','wait/io/file/innodb/innodb_log_file',14),('/var/lib/mysql/#innodb_redo/#ib_redo7_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo8_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo9_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo10_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo11_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/undo_001','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#innodb_redo/#ib_redo12_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/undo_002','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#innodb_redo/#ib_redo13_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo14_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo15_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/ibtmp1','wait/io/file/innodb/innodb_data_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo16_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_temp/temp_1.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_temp/temp_2.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo17_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_temp/temp_3.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_temp/temp_4.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo18_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_temp/temp_5.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_temp/temp_6.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_temp/temp_7.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_temp/temp_8.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo19_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_temp/temp_9.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo20_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_temp/temp_10.ibt','wait/io/file/innodb/innodb_temp_file',2),('/var/lib/mysql/#innodb_redo/#ib_redo21_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/mysql.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#innodb_redo/#ib_redo22_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo23_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo24_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo25_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo26_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo27_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo28_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo29_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo30_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo31_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/sys/sys_config.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_users.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_usermeta.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_termmeta.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_terms.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#innodb_redo/#ib_redo32_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/wordpress/wp_term_taxonomy.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_term_relationships.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_commentmeta.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_comments.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_links.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_options.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_postmeta.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/wordpress/wp_posts.ibd','wait/io/file/innodb/innodb_data_file',3),('/var/lib/mysql/#innodb_redo/#ib_redo33_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo34_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo35_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo36_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/#innodb_redo/#ib_redo37_tmp','wait/io/file/innodb/innodb_log_file',1),('/var/lib/mysql/binlog.000006','wait/io/file/sql/binlog',0),('/var/lib/mysql/binlog.000007','wait/io/file/sql/binlog',1),('/var/lib/mysql/binlog.index','wait/io/file/sql/binlog_index',1),('/var/lib/mysql/binlog.000001','wait/io/file/sql/binlog',0),('/run/mysqld/mysqld.pid','wait/io/file/sql/pid',0),('/var/lib/mysql/mysql/general_log.CSM','wait/io/file/csv/metadata',0),('/var/lib/mysql/mysql/general_log.CSV','wait/io/file/csv/data',0),('/var/lib/mysql/mysql/slow_log.CSM','wait/io/file/csv/metadata',0),('/var/lib/mysql/mysql/slow_log.CSV','wait/io/file/csv/data',0);
/*!40000 ALTER TABLE `file_instances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:10
