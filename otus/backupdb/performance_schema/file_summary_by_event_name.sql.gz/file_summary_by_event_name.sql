-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `file_summary_by_event_name`
--

DROP TABLE IF EXISTS `file_summary_by_event_name`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_summary_by_event_name` (
  `EVENT_NAME` varchar(128) NOT NULL,
  `COUNT_STAR` bigint unsigned NOT NULL,
  `SUM_TIMER_WAIT` bigint unsigned NOT NULL,
  `MIN_TIMER_WAIT` bigint unsigned NOT NULL,
  `AVG_TIMER_WAIT` bigint unsigned NOT NULL,
  `MAX_TIMER_WAIT` bigint unsigned NOT NULL,
  `COUNT_READ` bigint unsigned NOT NULL,
  `SUM_TIMER_READ` bigint unsigned NOT NULL,
  `MIN_TIMER_READ` bigint unsigned NOT NULL,
  `AVG_TIMER_READ` bigint unsigned NOT NULL,
  `MAX_TIMER_READ` bigint unsigned NOT NULL,
  `SUM_NUMBER_OF_BYTES_READ` bigint NOT NULL,
  `COUNT_WRITE` bigint unsigned NOT NULL,
  `SUM_TIMER_WRITE` bigint unsigned NOT NULL,
  `MIN_TIMER_WRITE` bigint unsigned NOT NULL,
  `AVG_TIMER_WRITE` bigint unsigned NOT NULL,
  `MAX_TIMER_WRITE` bigint unsigned NOT NULL,
  `SUM_NUMBER_OF_BYTES_WRITE` bigint NOT NULL,
  `COUNT_MISC` bigint unsigned NOT NULL,
  `SUM_TIMER_MISC` bigint unsigned NOT NULL,
  `MIN_TIMER_MISC` bigint unsigned NOT NULL,
  `AVG_TIMER_MISC` bigint unsigned NOT NULL,
  `MAX_TIMER_MISC` bigint unsigned NOT NULL,
  PRIMARY KEY (`EVENT_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_summary_by_event_name`
--

LOCK TABLES `file_summary_by_event_name` WRITE;
/*!40000 ALTER TABLE `file_summary_by_event_name` DISABLE KEYS */;
INSERT INTO `file_summary_by_event_name` VALUES ('wait/io/file/sql/binlog',31,9178380483,0,296076677,4842025113,6,901064721,3077354,150177235,449170450,1108,3,93475611,19305786,31158537,47120399,158,22,8183840151,0,371992317,4842025113),('wait/io/file/sql/binlog_cache',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/binlog_index',23,7086538395,0,308110346,4421789307,5,1987519263,0,397503503,1842174374,416,0,0,0,0,0,0,18,5099019132,0,283278695,4421789307),('wait/io/file/sql/binlog_index_cache',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/relaylog',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/relaylog_cache',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/relaylog_index',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/relaylog_index_cache',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/io_cache',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/casetest',15,22449236687,0,1496615750,19878839395,0,0,0,0,0,0,0,0,0,0,0,0,15,22449236687,0,1496615750,19878839395),('wait/io/file/sql/dbopt',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/ERRMSG',5,6043883052,31863418,1208776523,3214485037,3,4190471223,473514846,1396823741,3214485037,369516,0,0,0,0,0,0,2,1853411829,31863418,926705696,1821548411),('wait/io/file/sql/select_to_file',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/file_parser',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/FRM',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/load',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/LOAD_FILE',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/log_event_data',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/log_event_info',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/misc',5,111541628,0,22307976,39621479,0,0,0,0,0,0,0,0,0,0,0,0,5,111541628,0,22307976,39621479),('wait/io/file/sql/pid',3,94766072,6648081,31588545,68955104,0,0,0,0,0,0,1,19162887,19162887,19162887,19162887,5,2,75603185,6648081,37801374,68955104),('wait/io/file/sql/query_log',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/slow_log',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/tclog',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/trigger_name',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/trigger',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/init',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/SDI',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/sql/hash_join',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/mysys/proc_meminfo',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/mysys/charset',3,670810732,14918306,223603286,604563717,1,604563717,604563717,604563717,604563717,19474,0,0,0,0,0,0,2,66247015,14918306,33123289,51328709),('wait/io/file/mysys/cnf',5,592030994,1783397,118406024,479963218,3,488709773,1783397,162903112,479963218,56,0,0,0,0,0,0,2,103321221,49942982,51660392,53378239),('wait/io/file/csv/metadata',48,28793060370,2553828,599855042,2650444330,6,1591810082,17540743,265301389,613185290,210,6,167968816,18744241,27994657,42175307,210,36,27033281472,2553828,750924194,2650444330),('wait/io/file/csv/data',46,1603867349,0,34866482,269670515,4,41552145,5514503,10387927,17609352,0,0,0,0,0,0,0,42,1562315204,0,37197877,269670515),('wait/io/file/csv/update',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/innodb/innodb_dblwr_file',56,162444520267,12622745,2900794638,19424813875,2,21370624110,1945810235,10685312055,19424813875,8781824,24,1949552266,30627582,81231308,257648208,1343488,30,139124343891,12622745,4637478086,12610370471),('wait/io/file/innodb/innodb_tablespace_open_file',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/innodb/innodb_data_file',2131,369045769336,0,173179604,40387034391,1780,173053685509,4570146,97221138,8570134167,29999104,225,18546284370,13288296,82427814,1836235981,16072704,126,177445799457,0,1408299798,40387034391),('wait/io/file/innodb/innodb_log_file',356,1273341804243,0,3576802611,47566546721,7,1116104992,3059437,159443383,561323004,68608,101,7908370646,4710423,78300349,2162987436,124928,248,1264317328605,0,5098053362,47566546721),('wait/io/file/innodb/innodb_temp_file',91,391740005266,0,4304834997,155244515259,3,79557161,10765495,26518908,46195707,49152,32,1413466449,18762158,44170649,240566315,917504,56,390246981656,0,6968696101,155244515259),('wait/io/file/innodb/innodb_arch_file',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/innodb/innodb_clone_file',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/innodb/meb::redo_log_archive_file',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/myisam/data_tmp',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/myisam/dfile',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/myisam/kfile',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/myisam/log',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/myisammrg/MRG',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/archive/metadata',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/archive/data',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),('wait/io/file/archive/FRM',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `file_summary_by_event_name` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:10
