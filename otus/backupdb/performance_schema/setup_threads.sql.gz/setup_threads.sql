-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `setup_threads`
--

DROP TABLE IF EXISTS `setup_threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setup_threads` (
  `NAME` varchar(128) NOT NULL,
  `ENABLED` enum('YES','NO') NOT NULL,
  `HISTORY` enum('YES','NO') NOT NULL,
  `PROPERTIES` set('singleton','user') NOT NULL,
  `VOLATILITY` int NOT NULL,
  `DOCUMENTATION` longtext,
  PRIMARY KEY (`NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setup_threads`
--

LOCK TABLES `setup_threads` WRITE;
/*!40000 ALTER TABLE `setup_threads` DISABLE KEYS */;
INSERT INTO `setup_threads` VALUES ('thread/performance_schema/setup','YES','YES','singleton',0,NULL),('thread/sql/bootstrap','YES','YES','singleton',0,NULL),('thread/sql/manager','YES','YES','singleton',0,NULL),('thread/sql/main','YES','YES','singleton',0,NULL),('thread/sql/one_connection','YES','YES','user',0,NULL),('thread/sql/signal_handler','YES','YES','singleton',0,NULL),('thread/sql/compress_gtid_table','YES','YES','singleton',0,NULL),('thread/sql/parser_service','YES','YES','singleton',0,NULL),('thread/sql/admin_interface','YES','YES','user',0,NULL),('thread/mysys/thread_timer_notifier','YES','YES','singleton',0,NULL),('thread/sql/event_scheduler','YES','YES','singleton',0,NULL),('thread/sql/event_worker','YES','YES','',0,NULL),('thread/innodb/log_archiver_thread','YES','YES','singleton',0,NULL),('thread/innodb/page_archiver_thread','YES','YES','singleton',0,NULL),('thread/innodb/buf_dump_thread','YES','YES','singleton',0,NULL),('thread/innodb/clone_ddl_thread','YES','YES','singleton',0,NULL),('thread/innodb/clone_gtid_thread','YES','YES','singleton',0,NULL),('thread/innodb/ddl_thread','YES','YES','',0,NULL),('thread/innodb/dict_stats_thread','YES','YES','singleton',0,NULL),('thread/innodb/io_handler_thread','YES','YES','singleton',0,NULL),('thread/innodb/io_ibuf_thread','YES','YES','singleton',0,NULL),('thread/innodb/io_log_thread','YES','YES','singleton',0,NULL),('thread/innodb/io_read_thread','YES','YES','',0,NULL),('thread/innodb/io_write_thread','YES','YES','',0,NULL),('thread/innodb/buf_resize_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_files_governor_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_writer_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_checkpointer_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_flusher_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_write_notifier_thread','YES','YES','singleton',0,NULL),('thread/innodb/log_flush_notifier_thread','YES','YES','singleton',0,NULL),('thread/innodb/recv_writer_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_error_monitor_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_lock_timeout_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_master_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_monitor_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_purge_thread','YES','YES','singleton',0,NULL),('thread/innodb/srv_worker_thread','YES','YES','',0,NULL),('thread/innodb/trx_recovery_rollback_thread','YES','YES','',0,NULL),('thread/innodb/page_flush_thread','YES','YES','',0,NULL),('thread/innodb/page_flush_coordinator_thread','YES','YES','singleton',0,NULL),('thread/innodb/fts_optimize_thread','YES','YES','singleton',0,NULL),('thread/innodb/fts_parallel_merge_thread','YES','YES','',0,NULL),('thread/innodb/fts_parallel_tokenization_thread','YES','YES','',0,NULL),('thread/innodb/srv_ts_alter_encrypt_thread','YES','YES','singleton',0,NULL),('thread/innodb/parallel_read_thread','YES','YES','',0,NULL),('thread/innodb/parallel_rseg_init_thread','YES','YES','',0,NULL),('thread/innodb/meb::redo_log_archive_consumer_thread','YES','YES','singleton',0,NULL),('thread/myisam/find_all_keys','YES','YES','',0,NULL),('thread/mysqlx/acceptor_network','YES','YES','',0,NULL),('thread/mysqlx/worker','YES','YES','user',0,NULL),('thread/sql/replica_io','YES','YES','',0,NULL),('thread/sql/replica_sql','YES','YES','',0,NULL),('thread/sql/replica_worker','YES','YES','',0,NULL),('thread/sql/replica_monitor','YES','YES','singleton',0,NULL);
/*!40000 ALTER TABLE `setup_threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:12
