-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `status_by_account`
--

DROP TABLE IF EXISTS `status_by_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_by_account` (
  `USER` char(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `HOST` char(255) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `VARIABLE_NAME` varchar(64) NOT NULL,
  `VARIABLE_VALUE` varchar(1024) DEFAULT NULL,
  UNIQUE KEY `ACCOUNT` (`USER`,`HOST`,`VARIABLE_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_by_account`
--

LOCK TABLES `status_by_account` WRITE;
/*!40000 ALTER TABLE `status_by_account` DISABLE KEYS */;
INSERT INTO `status_by_account` VALUES (NULL,NULL,'Bytes_received','0'),(NULL,NULL,'Bytes_sent','0'),(NULL,NULL,'Com_stmt_reprepare','0'),(NULL,NULL,'Created_tmp_disk_tables','0'),(NULL,NULL,'Created_tmp_tables','0'),(NULL,NULL,'Handler_commit','0'),(NULL,NULL,'Handler_delete','0'),(NULL,NULL,'Handler_discover','0'),(NULL,NULL,'Handler_external_lock','0'),(NULL,NULL,'Handler_mrr_init','0'),(NULL,NULL,'Handler_prepare','0'),(NULL,NULL,'Handler_read_first','0'),(NULL,NULL,'Handler_read_key','0'),(NULL,NULL,'Handler_read_last','0'),(NULL,NULL,'Handler_read_next','0'),(NULL,NULL,'Handler_read_prev','0'),(NULL,NULL,'Handler_read_rnd','0'),(NULL,NULL,'Handler_read_rnd_next','0'),(NULL,NULL,'Handler_rollback','0'),(NULL,NULL,'Handler_savepoint','0'),(NULL,NULL,'Handler_savepoint_rollback','0'),(NULL,NULL,'Handler_update','0'),(NULL,NULL,'Handler_write','0'),(NULL,NULL,'Max_execution_time_exceeded','0'),(NULL,NULL,'Max_execution_time_set','0'),(NULL,NULL,'Max_execution_time_set_failed','0'),(NULL,NULL,'Opened_table_definitions','0'),(NULL,NULL,'Opened_tables','0'),(NULL,NULL,'Questions','0'),(NULL,NULL,'Secondary_engine_execution_count','0'),(NULL,NULL,'Select_full_join','0'),(NULL,NULL,'Select_full_range_join','0'),(NULL,NULL,'Select_range','0'),(NULL,NULL,'Select_range_check','0'),(NULL,NULL,'Select_scan','0'),(NULL,NULL,'Slow_queries','0'),(NULL,NULL,'Sort_merge_passes','0'),(NULL,NULL,'Sort_range','0'),(NULL,NULL,'Sort_rows','0'),(NULL,NULL,'Sort_scan','0'),(NULL,NULL,'Table_open_cache_hits','0'),(NULL,NULL,'Table_open_cache_misses','0'),(NULL,NULL,'Table_open_cache_overflows','0'),('event_scheduler','localhost','Bytes_received','0'),('event_scheduler','localhost','Bytes_sent','0'),('event_scheduler','localhost','Com_stmt_reprepare','0'),('event_scheduler','localhost','Created_tmp_disk_tables','0'),('event_scheduler','localhost','Created_tmp_tables','0'),('event_scheduler','localhost','Handler_commit','0'),('event_scheduler','localhost','Handler_delete','0'),('event_scheduler','localhost','Handler_discover','0'),('event_scheduler','localhost','Handler_external_lock','0'),('event_scheduler','localhost','Handler_mrr_init','0'),('event_scheduler','localhost','Handler_prepare','0'),('event_scheduler','localhost','Handler_read_first','0'),('event_scheduler','localhost','Handler_read_key','0'),('event_scheduler','localhost','Handler_read_last','0'),('event_scheduler','localhost','Handler_read_next','0'),('event_scheduler','localhost','Handler_read_prev','0'),('event_scheduler','localhost','Handler_read_rnd','0'),('event_scheduler','localhost','Handler_read_rnd_next','0'),('event_scheduler','localhost','Handler_rollback','0'),('event_scheduler','localhost','Handler_savepoint','0'),('event_scheduler','localhost','Handler_savepoint_rollback','0'),('event_scheduler','localhost','Handler_update','0'),('event_scheduler','localhost','Handler_write','0'),('event_scheduler','localhost','Max_execution_time_exceeded','0'),('event_scheduler','localhost','Max_execution_time_set','0'),('event_scheduler','localhost','Max_execution_time_set_failed','0'),('event_scheduler','localhost','Opened_table_definitions','0'),('event_scheduler','localhost','Opened_tables','0'),('event_scheduler','localhost','Questions','0'),('event_scheduler','localhost','Secondary_engine_execution_count','0'),('event_scheduler','localhost','Select_full_join','0'),('event_scheduler','localhost','Select_full_range_join','0'),('event_scheduler','localhost','Select_range','0'),('event_scheduler','localhost','Select_range_check','0'),('event_scheduler','localhost','Select_scan','0'),('event_scheduler','localhost','Slow_queries','0'),('event_scheduler','localhost','Sort_merge_passes','0'),('event_scheduler','localhost','Sort_range','0'),('event_scheduler','localhost','Sort_rows','0'),('event_scheduler','localhost','Sort_scan','0'),('event_scheduler','localhost','Table_open_cache_hits','0'),('event_scheduler','localhost','Table_open_cache_misses','0'),('event_scheduler','localhost','Table_open_cache_overflows','0'),('root','localhost','Bytes_received','3195037'),('root','localhost','Bytes_sent','81947427'),('root','localhost','Com_stmt_reprepare','0'),('root','localhost','Created_tmp_disk_tables','18'),('root','localhost','Created_tmp_tables','10357'),('root','localhost','Handler_commit','13601'),('root','localhost','Handler_delete','0'),('root','localhost','Handler_discover','0'),('root','localhost','Handler_external_lock','166963'),('root','localhost','Handler_mrr_init','0'),('root','localhost','Handler_prepare','0'),('root','localhost','Handler_read_first','10612'),('root','localhost','Handler_read_key','58059'),('root','localhost','Handler_read_last','0'),('root','localhost','Handler_read_next','267177'),('root','localhost','Handler_read_prev','0'),('root','localhost','Handler_read_rnd','17897'),('root','localhost','Handler_read_rnd_next','2397653'),('root','localhost','Handler_rollback','258'),('root','localhost','Handler_savepoint','171'),('root','localhost','Handler_savepoint_rollback','170'),('root','localhost','Handler_update','0'),('root','localhost','Handler_write','19278'),('root','localhost','Max_execution_time_exceeded','0'),('root','localhost','Max_execution_time_set','0'),('root','localhost','Max_execution_time_set_failed','0'),('root','localhost','Opened_table_definitions','6387'),('root','localhost','Opened_tables','8757'),('root','localhost','Questions','31551'),('root','localhost','Secondary_engine_execution_count','0'),('root','localhost','Select_full_join','3248'),('root','localhost','Select_full_range_join','0'),('root','localhost','Select_range','0'),('root','localhost','Select_range_check','0'),('root','localhost','Select_scan','14068'),('root','localhost','Slow_queries','0'),('root','localhost','Sort_merge_passes','0'),('root','localhost','Sort_range','0'),('root','localhost','Sort_rows','21430'),('root','localhost','Sort_scan','7674'),('root','localhost','Table_open_cache_hits','76163'),('root','localhost','Table_open_cache_misses','8757'),('root','localhost','Table_open_cache_overflows','0');
/*!40000 ALTER TABLE `status_by_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
