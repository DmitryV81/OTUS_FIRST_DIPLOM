-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `status_by_thread`
--

DROP TABLE IF EXISTS `status_by_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_by_thread` (
  `THREAD_ID` bigint unsigned NOT NULL,
  `VARIABLE_NAME` varchar(64) NOT NULL,
  `VARIABLE_VALUE` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`THREAD_ID`,`VARIABLE_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_by_thread`
--

LOCK TABLES `status_by_thread` WRITE;
/*!40000 ALTER TABLE `status_by_thread` DISABLE KEYS */;
INSERT INTO `status_by_thread` VALUES (1453,'Bytes_received','2265'),(1453,'Bytes_sent','4465'),(1453,'Com_stmt_reprepare','0'),(1453,'Compression','OFF'),(1453,'Compression_algorithm',''),(1453,'Compression_level','0'),(1453,'Created_tmp_disk_tables','0'),(1453,'Created_tmp_tables','8'),(1453,'Handler_commit','13'),(1453,'Handler_delete','0'),(1453,'Handler_discover','0'),(1453,'Handler_external_lock','133'),(1453,'Handler_mrr_init','0'),(1453,'Handler_prepare','0'),(1453,'Handler_read_first','7'),(1453,'Handler_read_key','44'),(1453,'Handler_read_last','0'),(1453,'Handler_read_next','240'),(1453,'Handler_read_prev','0'),(1453,'Handler_read_rnd','6'),(1453,'Handler_read_rnd_next','1356'),(1453,'Handler_rollback','0'),(1453,'Handler_savepoint','1'),(1453,'Handler_savepoint_rollback','0'),(1453,'Handler_update','0'),(1453,'Handler_write','7'),(1453,'Last_query_cost','20.908318'),(1453,'Last_query_partial_plans','45'),(1453,'Max_execution_time_exceeded','0'),(1453,'Max_execution_time_set','0'),(1453,'Max_execution_time_set_failed','0'),(1453,'Open_tables','31'),(1453,'Opened_table_definitions','28'),(1453,'Opened_tables','31'),(1453,'Queries','31638'),(1453,'Questions','25'),(1453,'Secondary_engine_execution_count','0'),(1453,'Select_full_join','2'),(1453,'Select_full_range_join','0'),(1453,'Select_range','0'),(1453,'Select_range_check','0'),(1453,'Select_scan','11'),(1453,'Slow_launch_threads','0'),(1453,'Slow_queries','0'),(1453,'Sort_merge_passes','0'),(1453,'Sort_range','0'),(1453,'Sort_rows','8'),(1453,'Sort_scan','6'),(1453,'Ssl_cipher',''),(1453,'Ssl_cipher_list',''),(1453,'Ssl_default_timeout','0'),(1453,'Ssl_server_not_after','Aug 14 05:33:11 2032 GMT'),(1453,'Ssl_server_not_before','Aug 17 05:33:11 2022 GMT'),(1453,'Ssl_sessions_reused','0'),(1453,'Ssl_verify_depth','0'),(1453,'Ssl_verify_mode','0'),(1453,'Ssl_version',''),(1453,'Table_open_cache_hits','38'),(1453,'Table_open_cache_misses','31'),(1453,'Table_open_cache_overflows','0');
/*!40000 ALTER TABLE `status_by_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
