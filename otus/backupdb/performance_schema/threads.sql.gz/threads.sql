-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `threads`
--

DROP TABLE IF EXISTS `threads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `threads` (
  `THREAD_ID` bigint unsigned NOT NULL,
  `NAME` varchar(128) NOT NULL,
  `TYPE` varchar(10) NOT NULL,
  `PROCESSLIST_ID` bigint unsigned DEFAULT NULL,
  `PROCESSLIST_USER` varchar(32) DEFAULT NULL,
  `PROCESSLIST_HOST` varchar(255) CHARACTER SET ascii COLLATE ascii_general_ci DEFAULT NULL,
  `PROCESSLIST_DB` varchar(64) DEFAULT NULL,
  `PROCESSLIST_COMMAND` varchar(16) DEFAULT NULL,
  `PROCESSLIST_TIME` bigint DEFAULT NULL,
  `PROCESSLIST_STATE` varchar(64) DEFAULT NULL,
  `PROCESSLIST_INFO` longtext,
  `PARENT_THREAD_ID` bigint unsigned DEFAULT NULL,
  `ROLE` varchar(64) DEFAULT NULL,
  `INSTRUMENTED` enum('YES','NO') NOT NULL,
  `HISTORY` enum('YES','NO') NOT NULL,
  `CONNECTION_TYPE` varchar(16) DEFAULT NULL,
  `THREAD_OS_ID` bigint unsigned DEFAULT NULL,
  `RESOURCE_GROUP` varchar(64) DEFAULT NULL,
  `EXECUTION_ENGINE` enum('PRIMARY','SECONDARY') DEFAULT NULL,
  PRIMARY KEY (`THREAD_ID`),
  KEY `PROCESSLIST_ID` (`PROCESSLIST_ID`),
  KEY `THREAD_OS_ID` (`THREAD_OS_ID`),
  KEY `NAME` (`NAME`),
  KEY `PROCESSLIST_ACCOUNT` (`PROCESSLIST_USER`,`PROCESSLIST_HOST`),
  KEY `PROCESSLIST_HOST` (`PROCESSLIST_HOST`),
  KEY `RESOURCE_GROUP` (`RESOURCE_GROUP`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `threads`
--

LOCK TABLES `threads` WRITE;
/*!40000 ALTER TABLE `threads` DISABLE KEYS */;
INSERT INTO `threads` VALUES (1,'thread/sql/main','BACKGROUND',NULL,NULL,NULL,'mysql',NULL,991,NULL,NULL,NULL,NULL,'YES','YES',NULL,1040,'SYS_default','PRIMARY'),(3,'thread/innodb/io_ibuf_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1206,'SYS_default','PRIMARY'),(4,'thread/innodb/io_log_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1219,'SYS_default','PRIMARY'),(5,'thread/innodb/io_read_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1231,'SYS_default','PRIMARY'),(6,'thread/innodb/io_read_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1239,'SYS_default','PRIMARY'),(7,'thread/innodb/io_read_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1254,'SYS_default','PRIMARY'),(8,'thread/innodb/io_read_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1262,'SYS_default','PRIMARY'),(9,'thread/innodb/io_write_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1264,'SYS_default','PRIMARY'),(10,'thread/innodb/io_write_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1268,'SYS_default','PRIMARY'),(11,'thread/innodb/io_write_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1272,'SYS_default','PRIMARY'),(12,'thread/innodb/io_write_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1275,'SYS_default','PRIMARY'),(13,'thread/innodb/page_flush_coordinator_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,993,NULL,NULL,NULL,NULL,'YES','YES',NULL,1278,'SYS_default','PRIMARY'),(15,'thread/innodb/log_checkpointer_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1286,'SYS_default','PRIMARY'),(16,'thread/innodb/log_flush_notifier_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1287,'SYS_default','PRIMARY'),(17,'thread/innodb/log_flusher_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1288,'SYS_default','PRIMARY'),(18,'thread/innodb/log_write_notifier_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1289,'SYS_default','PRIMARY'),(19,'thread/innodb/log_writer_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1290,'SYS_default','PRIMARY'),(20,'thread/innodb/log_files_governor_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1291,'SYS_default','PRIMARY'),(21,'thread/innodb/srv_lock_timeout_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1292,'SYS_default','PRIMARY'),(22,'thread/innodb/srv_error_monitor_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1293,'SYS_default','PRIMARY'),(23,'thread/innodb/srv_monitor_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1294,'SYS_default','PRIMARY'),(24,'thread/innodb/buf_resize_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1295,'SYS_default','PRIMARY'),(25,'thread/innodb/srv_master_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1296,'SYS_default','PRIMARY'),(26,'thread/innodb/dict_stats_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1297,'SYS_default','PRIMARY'),(27,'thread/innodb/fts_optimize_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1298,'SYS_default','PRIMARY'),(28,'thread/mysqlx/worker','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'YES','YES',NULL,1299,'USR_default','PRIMARY'),(29,'thread/mysqlx/worker','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'YES','YES',NULL,1300,'USR_default','PRIMARY'),(30,'thread/mysqlx/acceptor_network','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'YES','YES',NULL,1301,'SYS_default','PRIMARY'),(34,'thread/innodb/buf_dump_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'YES','YES',NULL,1305,'SYS_default','PRIMARY'),(35,'thread/innodb/clone_gtid_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,'waiting for handler commit',NULL,NULL,NULL,'YES','YES',NULL,1306,'SYS_default','PRIMARY'),(36,'thread/innodb/srv_purge_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1307,'SYS_default','PRIMARY'),(37,'thread/innodb/srv_worker_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1308,'SYS_default','PRIMARY'),(38,'thread/innodb/srv_worker_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1309,'SYS_default','PRIMARY'),(39,'thread/innodb/srv_worker_thread','BACKGROUND',NULL,NULL,NULL,NULL,NULL,992,NULL,NULL,NULL,NULL,'YES','YES',NULL,1310,'SYS_default','PRIMARY'),(40,'thread/sql/event_scheduler','FOREGROUND',5,'event_scheduler','localhost',NULL,'Daemon',991,'Waiting on empty queue',NULL,1,NULL,'YES','YES',NULL,1311,'SYS_default','PRIMARY'),(41,'thread/sql/signal_handler','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'YES','YES',NULL,1312,'SYS_default','PRIMARY'),(42,'thread/mysqlx/acceptor_network','BACKGROUND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'YES','YES',NULL,1313,'SYS_default','PRIMARY'),(44,'thread/sql/compress_gtid_table','FOREGROUND',7,NULL,NULL,NULL,'Daemon',991,'Suspending',NULL,1,NULL,'YES','YES',NULL,1315,'SYS_default','PRIMARY'),(1459,'thread/sql/one_connection','FOREGROUND',1430,'root','localhost','performance_schema','Query',0,'executing','SELECT /*!40001 SQL_NO_CACHE */ * FROM `threads`',NULL,NULL,'YES','YES','Socket',1707,'USR_default','PRIMARY');
/*!40000 ALTER TABLE `threads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
