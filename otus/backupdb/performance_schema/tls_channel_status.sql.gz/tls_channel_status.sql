-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `tls_channel_status`
--

DROP TABLE IF EXISTS `tls_channel_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tls_channel_status` (
  `CHANNEL` varchar(128) NOT NULL,
  `PROPERTY` varchar(128) NOT NULL,
  `VALUE` varchar(2048) NOT NULL
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tls_channel_status`
--

LOCK TABLES `tls_channel_status` WRITE;
/*!40000 ALTER TABLE `tls_channel_status` DISABLE KEYS */;
INSERT INTO `tls_channel_status` VALUES ('mysql_main','Enabled','Yes'),('mysql_main','Ssl_accept_renegotiates','0'),('mysql_main','Ssl_accepts','0'),('mysql_main','Ssl_callback_cache_hits','0'),('mysql_main','Ssl_client_connects','0'),('mysql_main','Ssl_connect_renegotiates','0'),('mysql_main','Ssl_ctx_verify_depth','-1'),('mysql_main','Ssl_ctx_verify_mode','5'),('mysql_main','Current_tls_ca','ca.pem'),('mysql_main','Current_tls_capath',''),('mysql_main','Current_tls_cert','server-cert.pem'),('mysql_main','Current_tls_cipher',''),('mysql_main','Current_tls_ciphersuites',''),('mysql_main','Current_tls_crl',''),('mysql_main','Current_tls_crlpath',''),('mysql_main','Current_tls_key','server-key.pem'),('mysql_main','Current_tls_version','TLSv1.2'),('mysql_main','Ssl_finished_accepts','0'),('mysql_main','Ssl_finished_connects','0'),('mysql_main','Ssl_server_not_after','Aug 14 05:33:11 2032 GMT'),('mysql_main','Ssl_server_not_before','Aug 17 05:33:11 2022 GMT'),('mysql_main','Ssl_session_cache_hits','0'),('mysql_main','Ssl_session_cache_misses','0'),('mysql_main','Ssl_session_cache_mode','SERVER'),('mysql_main','Ssl_session_cache_overflows','0'),('mysql_main','Ssl_session_cache_size','128'),('mysql_main','Ssl_session_cache_timeouts','0'),('mysql_main','Ssl_used_session_cache_entries','0'),('mysql_main','Ssl_session_cache_timeout','300'),('mysql_admin','Enabled','No'),('mysql_admin','Ssl_accept_renegotiates','0'),('mysql_admin','Ssl_accepts','0'),('mysql_admin','Ssl_callback_cache_hits','0'),('mysql_admin','Ssl_client_connects','0'),('mysql_admin','Ssl_connect_renegotiates','0'),('mysql_admin','Ssl_ctx_verify_depth','0'),('mysql_admin','Ssl_ctx_verify_mode','0'),('mysql_admin','Current_tls_ca',''),('mysql_admin','Current_tls_capath',''),('mysql_admin','Current_tls_cert',''),('mysql_admin','Current_tls_cipher',''),('mysql_admin','Current_tls_ciphersuites',''),('mysql_admin','Current_tls_crl',''),('mysql_admin','Current_tls_crlpath',''),('mysql_admin','Current_tls_key',''),('mysql_admin','Current_tls_version','TLSv1.2'),('mysql_admin','Ssl_finished_accepts','0'),('mysql_admin','Ssl_finished_connects','0'),('mysql_admin','Ssl_server_not_after',''),('mysql_admin','Ssl_server_not_before',''),('mysql_admin','Ssl_session_cache_hits','0'),('mysql_admin','Ssl_session_cache_misses','0'),('mysql_admin','Ssl_session_cache_mode','NONE'),('mysql_admin','Ssl_session_cache_overflows','0'),('mysql_admin','Ssl_session_cache_size','0'),('mysql_admin','Ssl_session_cache_timeouts','0'),('mysql_admin','Ssl_used_session_cache_entries','0'),('mysql_admin','Ssl_session_cache_timeout','0');
/*!40000 ALTER TABLE `tls_channel_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
