-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `user_defined_functions`
--

DROP TABLE IF EXISTS `user_defined_functions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_defined_functions` (
  `UDF_NAME` varchar(64) NOT NULL,
  `UDF_RETURN_TYPE` varchar(20) NOT NULL,
  `UDF_TYPE` varchar(20) NOT NULL,
  `UDF_LIBRARY` varchar(1024) DEFAULT NULL,
  `UDF_USAGE_COUNT` bigint DEFAULT NULL,
  PRIMARY KEY (`UDF_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_defined_functions`
--

LOCK TABLES `user_defined_functions` WRITE;
/*!40000 ALTER TABLE `user_defined_functions` DISABLE KEYS */;
INSERT INTO `user_defined_functions` VALUES ('asynchronous_connection_failover_reset','char','function',NULL,1),('asynchronous_connection_failover_delete_source','char','function',NULL,1),('asynchronous_connection_failover_add_source','char','function',NULL,1),('innodb_set_open_files_limit','integer','function',NULL,1),('innodb_redo_log_archive_start','integer','function',NULL,1),('innodb_redo_log_archive_stop','integer','function',NULL,1),('mysqlx_generate_document_id','char','function',NULL,1),('innodb_redo_log_archive_flush','integer','function',NULL,1),('asynchronous_connection_failover_add_managed','char','function',NULL,1),('innodb_redo_log_consumer_advance','integer','function',NULL,1),('asynchronous_connection_failover_delete_managed','char','function',NULL,1),('mysqlx_get_prepared_statement_id','integer','function',NULL,1),('innodb_redo_log_consumer_register','integer','function',NULL,1),('innodb_redo_log_consumer_unregister','integer','function',NULL,1),('innodb_redo_log_sharp_checkpoint','integer','function',NULL,1),('mysqlx_error','char','function',NULL,1);
/*!40000 ALTER TABLE `user_defined_functions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
