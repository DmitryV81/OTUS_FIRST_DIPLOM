-- MySQL dump 10.13  Distrib 8.0.30, for Linux (x86_64)
--
-- Host: localhost    Database: performance_schema
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Position to start replication or point-in-time recovery from
--

-- CHANGE MASTER TO MASTER_LOG_FILE='binlog.000007', MASTER_LOG_POS=157;

--
-- Table structure for table `variables_by_thread`
--

DROP TABLE IF EXISTS `variables_by_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `variables_by_thread` (
  `THREAD_ID` bigint unsigned NOT NULL,
  `VARIABLE_NAME` varchar(64) NOT NULL,
  `VARIABLE_VALUE` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`THREAD_ID`,`VARIABLE_NAME`)
) ENGINE=PERFORMANCE_SCHEMA DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `variables_by_thread`
--

LOCK TABLES `variables_by_thread` WRITE;
/*!40000 ALTER TABLE `variables_by_thread` DISABLE KEYS */;
INSERT INTO `variables_by_thread` VALUES (1464,'auto_increment_increment','1'),(1464,'auto_increment_offset','1'),(1464,'autocommit','ON'),(1464,'big_tables','OFF'),(1464,'binlog_direct_non_transactional_updates','OFF'),(1464,'binlog_format','ROW'),(1464,'binlog_row_image','FULL'),(1464,'binlog_row_value_options',''),(1464,'binlog_rows_query_log_events','OFF'),(1464,'binlog_transaction_compression','OFF'),(1464,'binlog_transaction_compression_level_zstd','3'),(1464,'block_encryption_mode','aes-128-ecb'),(1464,'bulk_insert_buffer_size','8388608'),(1464,'character_set_client','utf8mb4'),(1464,'character_set_connection','utf8mb4'),(1464,'character_set_database','utf8mb4'),(1464,'character_set_filesystem','binary'),(1464,'character_set_results','utf8mb4'),(1464,'character_set_server','utf8mb4'),(1464,'collation_connection','utf8mb4_0900_ai_ci'),(1464,'collation_database','utf8mb4_0900_ai_ci'),(1464,'collation_server','utf8mb4_0900_ai_ci'),(1464,'completion_type','NO_CHAIN'),(1464,'connection_memory_chunk_size','8912'),(1464,'connection_memory_limit','18446744073709551615'),(1464,'cte_max_recursion_depth','1000'),(1464,'default_collation_for_utf8mb4','utf8mb4_0900_ai_ci'),(1464,'default_storage_engine','InnoDB'),(1464,'default_table_encryption','OFF'),(1464,'default_tmp_storage_engine','InnoDB'),(1464,'default_week_format','0'),(1464,'div_precision_increment','4'),(1464,'end_markers_in_json','OFF'),(1464,'eq_range_index_dive_limit','200'),(1464,'error_count','0'),(1464,'explicit_defaults_for_timestamp','ON'),(1464,'external_user',''),(1464,'foreign_key_checks','ON'),(1464,'generated_random_password_length','20'),(1464,'global_connection_memory_tracking','OFF'),(1464,'group_concat_max_len','1024'),(1464,'group_replication_consistency','EVENTUAL'),(1464,'gtid_next','AUTOMATIC'),(1464,'gtid_owned',''),(1464,'histogram_generation_max_mem_size','20000000'),(1464,'identity','0'),(1464,'immediate_server_version','999999'),(1464,'information_schema_stats_expiry','0'),(1464,'innodb_ddl_buffer_size','1048576'),(1464,'innodb_ddl_threads','4'),(1464,'innodb_ft_enable_stopword','ON'),(1464,'innodb_ft_user_stopword_table',''),(1464,'innodb_lock_wait_timeout','50'),(1464,'innodb_parallel_read_threads','4'),(1464,'innodb_strict_mode','ON'),(1464,'innodb_table_locks','ON'),(1464,'innodb_tmpdir',''),(1464,'insert_id','0'),(1464,'interactive_timeout','28800'),(1464,'internal_tmp_mem_storage_engine','TempTable'),(1464,'join_buffer_size','262144'),(1464,'keep_files_on_create','OFF'),(1464,'last_insert_id','0'),(1464,'lc_messages','en_US'),(1464,'lc_time_names','en_US'),(1464,'lock_wait_timeout','31536000'),(1464,'long_query_time','10.000000'),(1464,'low_priority_updates','OFF'),(1464,'max_allowed_packet','67108864'),(1464,'max_delayed_threads','20'),(1464,'max_error_count','1024'),(1464,'max_execution_time','0'),(1464,'max_heap_table_size','16777216'),(1464,'max_insert_delayed_threads','20'),(1464,'max_join_size','18446744073709551615'),(1464,'max_length_for_sort_data','4096'),(1464,'max_points_in_geometry','65536'),(1464,'max_seeks_for_key','18446744073709551615'),(1464,'max_sort_length','1024'),(1464,'max_sp_recursion_depth','0'),(1464,'max_user_connections','0'),(1464,'min_examined_row_limit','0'),(1464,'myisam_sort_buffer_size','8388608'),(1464,'myisam_stats_method','nulls_unequal'),(1464,'mysqlx_read_timeout','30'),(1464,'mysqlx_wait_timeout','28800'),(1464,'mysqlx_write_timeout','60'),(1464,'net_buffer_length','16384'),(1464,'net_read_timeout','86400'),(1464,'net_retry_count','10'),(1464,'net_write_timeout','86400'),(1464,'new','OFF'),(1464,'old_alter_table','OFF'),(1464,'optimizer_max_subgraph_pairs','100000'),(1464,'optimizer_prune_level','1'),(1464,'optimizer_search_depth','62'),(1464,'optimizer_switch','index_merge=on,index_merge_union=on,index_merge_sort_union=on,index_merge_intersection=on,engine_condition_pushdown=on,index_condition_pushdown=on,mrr=on,mrr_cost_based=on,block_nested_loop=on,batched_key_access=off,materialization=on,semijoin=on,loosescan=on,firstmatch=on,duplicateweedout=on,subquery_materialization_cost_based=on,use_index_extensions=on,condition_fanout_filter=on,derived_merge=on,use_invisible_indexes=off,skip_scan=on,hash_join=on,subquery_to_derived=off,prefer_ordering_index=on,hypergraph_optimizer=off,derived_condition_pushdown=on'),(1464,'optimizer_trace','enabled=off,one_line=off'),(1464,'optimizer_trace_features','greedy_search=on,range_optimizer=on,dynamic_range=on,repeated_subselect=on'),(1464,'optimizer_trace_limit','1'),(1464,'optimizer_trace_max_mem_size','1048576'),(1464,'optimizer_trace_offset','-1'),(1464,'original_commit_timestamp','36028797018963968'),(1464,'original_server_version','999999'),(1464,'parser_max_mem_size','18446744073709551615'),(1464,'preload_buffer_size','32768'),(1464,'print_identified_with_as_hex','OFF'),(1464,'profiling','OFF'),(1464,'profiling_history_size','15'),(1464,'proxy_user',''),(1464,'pseudo_replica_mode','OFF'),(1464,'pseudo_slave_mode','OFF'),(1464,'pseudo_thread_id','1435'),(1464,'query_alloc_block_size','8192'),(1464,'query_prealloc_size','8192'),(1464,'rand_seed1','0'),(1464,'rand_seed2','0'),(1464,'range_alloc_block_size','4096'),(1464,'range_optimizer_max_mem_size','8388608'),(1464,'rbr_exec_mode','STRICT'),(1464,'read_buffer_size','131072'),(1464,'read_rnd_buffer_size','262144'),(1464,'require_row_format','OFF'),(1464,'resultset_metadata','FULL'),(1464,'secondary_engine_cost_threshold','100000.000000'),(1464,'select_into_buffer_size','131072'),(1464,'select_into_disk_sync','OFF'),(1464,'select_into_disk_sync_delay','0'),(1464,'session_track_gtids','OFF'),(1464,'session_track_schema','ON'),(1464,'session_track_state_change','OFF'),(1464,'session_track_system_variables','time_zone,autocommit,character_set_client,character_set_results,character_set_connection'),(1464,'session_track_transaction_info','OFF'),(1464,'show_create_table_skip_secondary_engine','OFF'),(1464,'show_create_table_verbosity','OFF'),(1464,'show_gipk_in_create_table_and_information_schema','ON'),(1464,'show_old_temporals','OFF'),(1464,'sort_buffer_size','262144'),(1464,'sql_auto_is_null','OFF'),(1464,'sql_big_selects','ON'),(1464,'sql_buffer_result','OFF'),(1464,'sql_generate_invisible_primary_key','OFF'),(1464,'sql_log_bin','ON'),(1464,'sql_log_off','OFF'),(1464,'sql_mode',''),(1464,'sql_notes','ON'),(1464,'sql_quote_show_create','ON'),(1464,'sql_require_primary_key','OFF'),(1464,'sql_safe_updates','OFF'),(1464,'sql_select_limit','18446744073709551615'),(1464,'sql_warnings','OFF'),(1464,'terminology_use_previous','NONE'),(1464,'time_zone','+00:00'),(1464,'timestamp','1660760773.848679'),(1464,'tmp_table_size','16777216'),(1464,'transaction_alloc_block_size','8192'),(1464,'transaction_allow_batching','OFF'),(1464,'transaction_isolation','REPEATABLE-READ'),(1464,'transaction_prealloc_size','4096'),(1464,'transaction_read_only','OFF'),(1464,'transaction_write_set_extraction','XXHASH64'),(1464,'unique_checks','ON'),(1464,'updatable_views_with_limit','YES'),(1464,'use_secondary_engine','ON'),(1464,'wait_timeout','28800'),(1464,'warning_count','1'),(1464,'windowing_use_high_precision','ON'),(1464,'xa_detach_on_prepare','ON');
/*!40000 ALTER TABLE `variables_by_thread` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'performance_schema'
--

--
-- Dumping routines for database 'performance_schema'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-17 21:26:13
